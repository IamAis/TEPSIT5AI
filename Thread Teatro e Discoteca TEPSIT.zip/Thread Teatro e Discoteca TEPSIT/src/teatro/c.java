package teatro;

import java.util.Arrays;

class Cinema {
    private final int[][] posti;
    private int postiDisponibili = 15 * 46; 

    public Cinema() {
        posti = new int[15][46]; 
    }

    // Metodo per prenotare un posto specifico
    public synchronized boolean prenotaPosto(int fila, int posto) {
        if (fila < 0 || fila >= 15 || posto < 0 || posto >= 46) {
            System.out.println("Errore: Il posto scelto non esiste. Riprova.");
            return false;
        }

        if (posti[fila][posto] == 1) {
            System.out.println("Errore: Il posto " + (posto + 1) + " nella fila " + (fila + 1) + " è già occupato.");
            return false;
        }

        // Prenota il posto
        posti[fila][posto] = 1; 
        postiDisponibili--;
        return true;
    }

    // Metodo per stampare la matrice dei posti
    public synchronized void stampaMatricePosti() {
        System.out.println("\nStato attuale dei posti (0 = libero, 1 = occupato):");
        for (int[] fila : posti) {
            for (int posto : fila) {
                System.out.print(posto + " ");
            }
            System.out.println();
        }
    }

    // Trick per "pulire" los schermo
    public void clearScreen() {
        for (int i = 0; i < 50; i++) {
            System.out.println();
        }
    }

    public synchronized int getPostiDisponibili() {
        return postiDisponibili;
    }
}









