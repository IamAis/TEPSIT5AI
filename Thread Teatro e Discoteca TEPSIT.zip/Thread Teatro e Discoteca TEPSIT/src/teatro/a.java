package teatro;

import java.util.Scanner;

class ThreadManager {
    public static void main(String[] args) {
        Cinema cinema = new Cinema();
        Scanner scanner = new Scanner(System.in);
        boolean continua = true;

        while (continua) {
            System.out.println("Quanti thread vuoi usare? (da 1 a 7)");
            int numeroThread = scanner.nextInt();

            // Controlla che il numero di thread non superi il numero di posti disponibili
            if (numeroThread > cinema.getPostiDisponibili()) {
                System.out.println("Errore: Non ci sono abbastanza posti disponibili per tutti i thread.");
                continue;
            }

            Thread[] threads = new Thread[numeroThread];

            // Per ogni thread, l'utente sceglie quale posto prenoterà
            for (int i = 0; i < numeroThread; i++) {
                int fila = -1;
                int posto = -1;
                boolean sceltaValida = false;

                
                while (!sceltaValida) {
                    System.out.println("Scegli il posto che il Thread-" + (i + 1) + " prenoterà.");
                    System.out.println("Inserisci il numero della fila (1-15): ");
                    fila = scanner.nextInt() - 1;  

                    System.out.println("Inserisci il numero del posto (1-46): ");
                    posto = scanner.nextInt() - 1;  

                    // Controllo validità della scelta immediatamente dopo l'inserimento
                    if (fila >= 0 && fila < 15 && posto >= 0 && posto < 46) {
                        
                        if (cinema.prenotaPosto(fila, posto)) {
                            sceltaValida = true;
                        }
                    } else {
                        System.out.println("Errore: Il posto scelto non è valido. Riprova.");
                    }
                }
                threads[i] = new Thread(new Spettatore(cinema, fila, posto), "Thread-" + (i + 1));
            }

            // Avvio tutti i thread contemporaneamente
            System.out.println("Avvio tutti i thread...");
            for (Thread thread : threads) {
                thread.start();
            }

            // Pulisco lo schermo e stampo la matrice aggiornata
            cinema.clearScreen();
            cinema.stampaMatricePosti();

            // Chiedi all'utente se vuole continuare
            System.out.println("Vuoi prenotare altri posti? (s/n)");
            String risposta = scanner.next().toLowerCase();
            continua = risposta.equals("s");
        }

        System.out.println("Fine");
    }
}
