package teatro;

class Spettatore implements Runnable {
    private final Cinema cinema;
    private final int fila;
    private final int posto;

    public Spettatore(Cinema cinema, int fila, int posto) {
        this.cinema = cinema;
        this.fila = fila;
        this.posto = posto;
    }

    @Override
    public void run() {
        // Tentativo di prenotazione
        cinema.prenotaPosto(fila, posto);
    }
}







