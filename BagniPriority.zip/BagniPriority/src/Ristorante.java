public class Ristorante {
    private int personeInToilette = 0; // Numero di persone attualmente in toilette
    private boolean donneInToilette = false; // Indica se ci sono donne nella toilette
    private int donneInAttesa = 0; // Numero di donne in attesa
    private int uominiInAttesa = 0; // Numero di uomini in attesa

    // Metodo per l'accesso delle donne alla toilette
    public synchronized void entraDonna() throws InterruptedException {
        donneInAttesa++; // Incrementa il numero di donne in attesa
        while (personeInToilette > 0 && !donneInToilette) { // Aspetta che la toilette sia vuota o adatta
            wait();
        }
        donneInAttesa--; // La donna sta entrando, quindi non è più in attesa
        donneInToilette = true; // Indica che ci sono donne nella toilette
        personeInToilette++; // Incrementa il numero di persone nella toilette
    }

    // Metodo per l'uscita delle donne dalla toilette
    public synchronized void esciDonna() {
        personeInToilette--; // La donna esce dalla toilette
        if (personeInToilette == 0) { // Se l'ultima donna esce
            donneInToilette = false; // Non ci sono più donne nella toilette
            notifyAll(); // Notifica a tutti i thread in attesa
        }
    }

    // Metodo per l'accesso degli uomini alla toilette
    public synchronized void entraUomo() throws InterruptedException {
        uominiInAttesa++; // Incrementa il numero di uomini in attesa
        while (personeInToilette > 0 || donneInAttesa > 0) { // Aspetta che la toilette sia vuota e che non ci siano donne in attesa
            wait();
        }
        uominiInAttesa--; // L'uomo sta entrando, quindi non è più in attesa
        personeInToilette++; // Incrementa il numero di persone nella toilette
    }

    // Metodo per l'uscita degli uomini dalla toilette
    public synchronized void esciUomo() {
        personeInToilette--; // L'uomo esce dalla toilette
        if (personeInToilette == 0) { // Se l'ultimo uomo esce
            notifyAll(); // Notifica a tutti i thread in attesa
        }
    }

    // Classe per simulare le persone che usano la toilette
    static class Persona implements Runnable{
        private final Ristorante ristorante;
        private final boolean donna;

        public Persona(Ristorante ristorante, boolean donna) {
            this.ristorante = ristorante;
            this.donna = donna;
        }

        @Override
        public void run() {
            try {
                if (donna) {
                    ristorante.entraDonna();
                    System.out.println(Thread.currentThread().getName() + " è entrata in toilette (Donna)");
                    Thread.sleep(1000); // Simula l'uso della toilette
                    ristorante.esciDonna();
                    System.out.println(Thread.currentThread().getName() + " è uscita dalla toilette (Donna)");
                } else {
                    ristorante.entraUomo();
                    System.out.println(Thread.currentThread().getName() + " è entrato in toilette (Uomo)");
                    Thread.sleep(1000); // Simula l'uso della toilette
                    ristorante.esciUomo();
                    System.out.println(Thread.currentThread().getName() + " è uscito dalla toilette (Uomo)");
                }
            } catch (InterruptedException e) {
                
            }
        }
    }

    // Metodo main per testare il programma
    public static void main(String[] args) {
        Ristorante ristorante = new Ristorante();

        // Creazione di thread per uomini e donne
        for (int i = 0; i < 5; i++) {
            new Thread(new Persona(ristorante, false)).start(); // Donne
            new Thread(new Persona(ristorante, true)).start(); // Uomo
        }
    }
}